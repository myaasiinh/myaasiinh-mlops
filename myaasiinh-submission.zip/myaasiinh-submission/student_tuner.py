
import tensorflow as tf
import tensorflow_transform as tft
from keras_tuner import HyperParameters, RandomSearch
from tfx.components.tuner.component import TunerFnResult
from typing import NamedTuple, Dict, Any, List

LABEL_KEY = "Target_xf"
def transformed_name(key):
    return key + "_xf"

FEATURE_KEYS = [
    "Gender_xf", "Scholarship holder_xf", "Tuition fees up to date_xf", 
    "Debtor_xf", "Age at enrollment_xf", "Displaced_xf", "Educational special needs_xf"
]

def _input_fn(file_pattern, tf_transform_output, num_epochs=None, batch_size=64):
    transformed_feature_spec = (
        tf_transform_output.transformed_feature_spec().copy()
    )

    def _gzip_reader(filenames):
        return tf.data.TFRecordDataset(filenames, compression_type='GZIP')

    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transformed_feature_spec,
        reader=_gzip_reader,
        num_epochs=num_epochs,
        label_key=LABEL_KEY
    )
    return dataset

def model_builder(hp: HyperParameters):
    hp_units = hp.Int('units', min_value=32, max_value=512, step=32)
    hp_lr = hp.Choice('learning_rate', values=[1e-2, 1e-3, 1e-4])
    
    inputs = {
        name: tf.keras.Input(shape=(1,), name=name, dtype=tf.float32)
        for name in FEATURE_KEYS
    }
    
    x = tf.stack(list(inputs.values()), axis=1)
    x = tf.keras.layers.Reshape((len(FEATURE_KEYS),))(x)
    
    x = tf.keras.layers.Dense(hp_units, activation='relu')(x)
    x = tf.keras.layers.Dense(hp_units // 2, activation='relu')(x)
    outputs = tf.keras.layers.Dense(1, activation='sigmoid')(x)
    
    model = tf.keras.Model(inputs=inputs, outputs=outputs)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=hp_lr),
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    return model

def tuner_fn(fn_args):
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)
    
    tuner = RandomSearch(
        model_builder,
        objective='val_accuracy',
        max_trials=5,
        executions_per_trial=1,
        directory=fn_args.working_dir,
        project_name='student_tuner'
    )
    
    train_dataset = _input_fn(
        fn_args.train_files,
        tf_transform_output,
        batch_size=64
    )
    eval_dataset = _input_fn(
        fn_args.eval_files,
        tf_transform_output,
        batch_size=64
    )
    
    tuner.search(
        train_dataset,
        validation_data=eval_dataset,
        epochs=5,
        steps_per_epoch=10,
        validation_steps=10
    )
    
    return TunerFnResult(
        tuner=tuner,
        fit_kwargs={
            'x': train_dataset,
            'validation_data': eval_dataset,
            'steps_per_epoch': 10,
            'validation_steps': 10
        }
    )
