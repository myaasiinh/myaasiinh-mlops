# Submission 1: Predicting Student Dropout and Academic Success
Nama: myaasiinh

Username dicoding: myaasiinh

| | Deskripsi |
| ----------- | ----------- |
| Dataset | [Predict Students' Dropout and Academic Success](https://archive.ics.uci.edu/dataset/697/predict+students+dropout+and+academic+success) |
| Masalah | Tingginya angka dropout pada institusi pendidikan tinggi yang berdampak pada keberlanjutan institusi dan masa depan mahasiswa. |
| Solusi machine learning | Membangun pipeline machine learning menggunakan TFX untuk memprediksi potensi dropout mahasiswa berdasarkan data tabular (subset 7 fitur demografi/finansial dan indikator biner). |
| Metode pengolahan | Transformasi data menggunakan TensorFlow Transform (TFT) untuk pemilihan fitur (Gender, Scholarship, Age, etc) dan mapping label Target ke binary classification (Dropout vs non-Dropout). |
| Arsitektur model | Deep Learning Model menggunakan Keras dengan input layer, dense layers dengan activation ReLU, dan output layer sigmoid untuk binary classification. Hyperparameter optimal dicari menggunakan Keras Tuner. |
| Metrik evaluasi | Binary Accuracy digunakan untuk mengevaluasi kemampuan model dalam membedakan mahasiswa yang dropout dan yang tidak. |
| Performa model | Binary accuracy pada data evaluasi: **0.7619** (berdasarkan output komponen Evaluator/TFMA). |

## Dataset

Dataset yang digunakan adalah **Predict Students' Dropout and Academic Success** dari UCI.

Ringkasan data (berdasarkan file `data/student_dropout.csv`):
- Jumlah data: **4.424 baris**
- Jumlah kolom: **35 kolom**
- Label/target: kolom **`Target`** dengan 3 nilai: `Dropout`, `Graduate`, `Enrolled`
- Distribusi label:
	- `Dropout`: **1421**
	- `Graduate`: **2209**
	- `Enrolled`: **794**

Fitur yang dipakai pada model ini (subset dari dataset, total **7 fitur**):
- **Numerikal**: `Age at enrollment`
- **Biner (0/1)**: `Gender`, `Scholarship holder`, `Tuition fees up to date`, `Debtor`, `Displaced`, `Educational special needs`

Catatan: Problem yang diselesaikan adalah **klasifikasi biner berbasis data tabular** (bukan klasifikasi teks).

## Solusi Machine Learning

Solusi yang dibuat adalah pipeline TFX untuk memprediksi risiko **dropout** mahasiswa menggunakan model **Neural Network (Multi-Layer Perceptron / MLP) berbasis Keras**.

Target prediksi:
- Label asli `Target` dipetakan menjadi **biner**:
	- `Dropout` → **0**
	- `Graduate` atau `Enrolled` → **1** (non-dropout)

## Metode Pengolahan Data

Komponen pipeline yang digunakan: `ExampleGen → StatisticsGen → SchemaGen → ExampleValidator → Transform → Tuner → Trainer → Resolver → Evaluator → Pusher`.

Detail preprocessing (di `student_transform.py`):
- Menggunakan TensorFlow Transform (TFT) untuk membentuk dataset hasil transform.
- Mengambil **7 fitur** di atas apa adanya (fitur sudah numerikal/biner).
- Melakukan transformasi label `Target` menjadi `Target_xf` (0/1) sesuai mapping pada bagian Solusi.

Pembagian data:
- `CsvExampleGen` membagi data menjadi:
	- **train ≈ 80%** (hash_buckets=8)
	- **eval ≈ 20%** (hash_buckets=2)
- Jumlah data evaluasi yang terbaca oleh TFMA: **928 contoh**.

## Arsitektur Model

Model yang digunakan adalah MLP (Keras Functional API) dengan input 7 fitur (masing-masing shape `(1,)`).

Arsitektur (di `student_trainer.py`):
- Input: 7 fitur numerikal/biner
- Penggabungan fitur: `tf.stack` lalu reshape menjadi vektor berukuran 7
- Dense #1: `Dense(units, activation='relu')` (nilai `units` dari hasil tuning)
- Dense #2: `Dense(64, activation='relu')`
- Output: `Dense(1, activation='sigmoid')` (probabilitas kelas non-dropout)

Hyperparameter & training setup:
- Hyperparameter tuning (di `student_tuner.py`, KerasTuner RandomSearch):
	- `units`: 32 sampai 512 (step 32)
	- `learning_rate`: {1e-2, 1e-3, 1e-4}
	- Objective: `val_accuracy`, max_trials=5
- Optimizer: `Adam(learning_rate=best_lr)`
- Loss: `binary_crossentropy`
- Metric: `accuracy`
- Batch size:
	- training dataset: **128** (Trainer)
	- tuning dataset: **64** (Tuner)
- Epoch: **10** (Trainer), **5** (Tuner)

## Metrik Evaluasi

Evaluasi menggunakan komponen `Evaluator` (TFMA) dengan metrik utama:
- `BinaryAccuracy`

## Performa Model

Berdasarkan artifact Evaluator (TFMA) pada split evaluasi:
- `binary_accuracy`: **0.7619**
- `accuracy`: **0.7619**
- `loss`: **0.5038**
- `example_count`: **928**

Model kemudian dipush oleh komponen `Pusher` sebagai SavedModel untuk kebutuhan serving.