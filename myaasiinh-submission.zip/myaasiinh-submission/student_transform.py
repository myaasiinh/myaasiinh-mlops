
import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "Target"
FEATURE_KEYS = [
    "Gender", "Scholarship holder", "Tuition fees up to date", 
    "Debtor", "Age at enrollment", "Displaced", "Educational special needs"
]

def transformed_name(key):
    return key + "_xf"

def preprocessing_fn(inputs):
    outputs = {}
    
    for key in FEATURE_KEYS:
        outputs[transformed_name(key)] = inputs[key]
        
    outputs[transformed_name(LABEL_KEY)] = tf.where(
            tf.equal(inputs[LABEL_KEY], "Dropout"),
        tf.cast(tf.constant(0), tf.int64),
        tf.cast(tf.constant(1), tf.int64)
    )
    
    return outputs
