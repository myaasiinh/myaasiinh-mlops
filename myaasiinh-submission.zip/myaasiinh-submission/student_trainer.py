
import tensorflow as tf
import tensorflow_transform as tft
from tensorflow.keras import layers, Model
from tfx.components.trainer.fn_args_utils import FnArgs
from typing import List

LABEL_KEY = "Target_xf"
def transformed_name(key):
    return key + "_xf"

FEATURE_KEYS = [
    "Gender_xf", "Scholarship holder_xf", "Tuition fees up to date_xf", 
    "Debtor_xf", "Age at enrollment_xf", "Displaced_xf", "Educational special needs_xf"
]

def _input_fn(file_pattern, tf_transform_output, num_epochs=None, batch_size=128):
    transformed_feature_spec = (
        tf_transform_output.transformed_feature_spec().copy()
    )

    def _gzip_reader(filenames):
        return tf.data.TFRecordDataset(filenames, compression_type='GZIP')

    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transformed_feature_spec,
        reader=_gzip_reader,
        num_epochs=num_epochs,
        label_key=LABEL_KEY
    )
    return dataset

def get_serve_tf_examples_fn(model, tf_transform_output):
    model.tft_layer = tf_transform_output.transform_features_layer()

    @tf.function(input_signature=[
        tf.TensorSpec(shape=[None], dtype=tf.string, name='examples')
    ])
    def serve_tf_examples_fn(serialized_tf_examples):
        feature_spec = tf_transform_output.raw_feature_spec()
        required_feature_spec = {
            k: v for k, v in feature_spec.items() if k in [
                "Gender", "Scholarship holder", "Tuition fees up to date", 
                "Debtor", "Age at enrollment", "Displaced", "Educational special needs"
            ]
        }
        parsed_features = tf.io.parse_example(
            serialized_tf_examples, required_feature_spec
        )
        transformed_features = model.tft_layer(parsed_features)
        
        # Ensure only the transformed features used for training are passed
        model_inputs = {
            k: transformed_features[k] for k in FEATURE_KEYS
        }
        
        return model(model_inputs)

    return serve_tf_examples_fn

def run_fn(fn_args: FnArgs):
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_output)
    
    train_dataset = _input_fn(
        fn_args.train_files, 
        tf_transform_output, 
        num_epochs=10
    )
    eval_dataset = _input_fn(
        fn_args.eval_files, 
        tf_transform_output, 
        num_epochs=5
    )
    
    # Use hyperparameters from Tuner if provided
    hp = fn_args.hyperparameters['values'] if fn_args.hyperparameters else {
        'units': 128, 'learning_rate': 0.001
    }
    
    inputs = {
        name: tf.keras.Input(shape=(1,), name=name, dtype=tf.float32)
        for name in FEATURE_KEYS
    }
    
    # Flatten inputs
    x = tf.stack(list(inputs.values()), axis=1)
    x = tf.keras.layers.Reshape((len(FEATURE_KEYS),))(x)
    
    x = layers.Dense(hp.get('units', 128), activation='relu')(x)
    x = layers.Dense(64, activation='relu')(x)
    outputs = layers.Dense(1, activation='sigmoid')(x)
    
    model = Model(inputs=inputs, outputs=outputs)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=hp.get('learning_rate', 0.01)),
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    
    model.fit(
        train_dataset,
        steps_per_epoch=fn_args.train_steps,
        validation_data=eval_dataset,
        validation_steps=fn_args.eval_steps,
        epochs=10
    )
    
    signatures = {
        'serving_default': get_serve_tf_examples_fn(model, tf_transform_output)
    }
    
    model.save(fn_args.serving_model_dir, save_format='tf', signatures=signatures)
