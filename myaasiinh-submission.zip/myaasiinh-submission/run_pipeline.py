
import os
import shutil

import tensorflow_model_analysis as tfma
from tfx.components import (
    CsvExampleGen,
    Evaluator,
    ExampleValidator,
    Pusher,
    SchemaGen,
    StatisticsGen,
    Trainer,
    Transform,
    Tuner,
)
from tfx.dsl.components.common.resolver import Resolver
from tfx.dsl.input_resolution.strategies.latest_blessed_model_strategy import (
    LatestBlessedModelStrategy,
)
from tfx.types import Channel
from tfx.types.standard_artifacts import Model, ModelBlessing
from tfx.orchestration import metadata
from tfx.orchestration.local.local_dag_runner import LocalDagRunner
from tfx.orchestration.pipeline import Pipeline
from tfx.proto import example_gen_pb2, pusher_pb2, trainer_pb2

def create_pipeline(
    pipeline_name: str,
    pipeline_root: str,
    metadata_path: str,
    serving_model_dir: str,
) -> Pipeline:
    # For first run stability, baseline model comparison can be disabled.
    # Set USE_BASELINE_MODEL=1 to enable baseline model in Evaluator.
    use_baseline_model = os.environ.get('USE_BASELINE_MODEL', '').strip() in (
        '1',
        'true',
        'True',
        'yes',
        'YES',
    )

    example_gen = CsvExampleGen(
        input_base='data',
        input_config=example_gen_pb2.Input(
            splits=[
                example_gen_pb2.Input.Split(
                    name='data',
                    pattern='student_dropout.csv',
                )
            ]
        ),
        output_config=example_gen_pb2.Output(
            split_config=example_gen_pb2.SplitConfig(
                splits=[
                    example_gen_pb2.SplitConfig.Split(
                        name='train',
                        hash_buckets=8,
                    ),
                    example_gen_pb2.SplitConfig.Split(
                        name='eval',
                        hash_buckets=2,
                    ),
                ]
            )
        ),
    )

    statistics_gen = StatisticsGen(examples=example_gen.outputs['examples'])

    schema_gen = SchemaGen(statistics=statistics_gen.outputs['statistics'])

    example_validator = ExampleValidator(
        statistics=statistics_gen.outputs['statistics'],
        schema=schema_gen.outputs['schema'],
    )

    transform = Transform(
        examples=example_gen.outputs['examples'],
        schema=schema_gen.outputs['schema'],
        module_file='student_transform.py',
    )

    tuner = Tuner(
        module_file='student_tuner.py',
        examples=transform.outputs['transformed_examples'],
        transform_graph=transform.outputs['transform_graph'],
        schema=schema_gen.outputs['schema'],
        train_args=trainer_pb2.TrainArgs(num_steps=20),
        eval_args=trainer_pb2.EvalArgs(num_steps=10),
    )

    trainer = Trainer(
        module_file='student_trainer.py',
        examples=transform.outputs['transformed_examples'],
        transform_graph=transform.outputs['transform_graph'],
        schema=schema_gen.outputs['schema'],
        hyperparameters=tuner.outputs['best_hyperparameters'],
        train_args=trainer_pb2.TrainArgs(num_steps=50),
        eval_args=trainer_pb2.EvalArgs(num_steps=20),
    )

    model_resolver = Resolver(
        strategy_class=LatestBlessedModelStrategy,
        model=Channel(type=Model),
        model_blessing=Channel(type=ModelBlessing),
    ).with_id('latest_blessed_model_resolver')

    eval_config = tfma.EvalConfig(
        model_specs=[tfma.ModelSpec(label_key='Target_xf')],
        slicing_specs=[tfma.SlicingSpec()],
        metrics_specs=[
            tfma.MetricsSpec(
                metrics=[
                    tfma.MetricConfig(class_name='ExampleCount'),
                    tfma.MetricConfig(
                        class_name='BinaryAccuracy',
                        threshold=tfma.MetricThreshold(
                            value_threshold=tfma.GenericValueThreshold(
                                lower_bound={'value': 0.1}
                            )
                        ),
                    ),
                ]
            )
        ],
    )

    evaluator_kwargs = dict(
        examples=transform.outputs['transformed_examples'],
        model=trainer.outputs['model'],
        eval_config=eval_config,
    )
    if use_baseline_model:
        evaluator_kwargs['baseline_model'] = model_resolver.outputs['model']

    evaluator = Evaluator(**evaluator_kwargs)

    pusher = Pusher(
        model=trainer.outputs['model'],
        model_blessing=evaluator.outputs['blessing'],
        push_destination=pusher_pb2.PushDestination(
            filesystem=pusher_pb2.PushDestination.Filesystem(
                base_directory=serving_model_dir
            )
        ),
    )

    return Pipeline(
        pipeline_name=pipeline_name,
        pipeline_root=pipeline_root,
        metadata_connection_config=metadata.sqlite_metadata_connection_config(
            metadata_path
        ),
        components=[
            example_gen,
            statistics_gen,
            schema_gen,
            example_validator,
            transform,
            tuner,
            trainer,
            model_resolver,
            evaluator,
            pusher,
        ],
        enable_cache=False,
    )


def main():
    pipeline_name = 'myaasiinh-pipeline'
    pipeline_root = os.path.join('pipelines', pipeline_name)
    metadata_path = os.path.join('metadata', pipeline_name, 'metadata.db')
    serving_model_dir = os.path.join('serving_model', pipeline_name)

    if os.path.exists(pipeline_root):
        shutil.rmtree(pipeline_root)

    pipeline = create_pipeline(
        pipeline_name=pipeline_name,
        pipeline_root=pipeline_root,
        metadata_path=metadata_path,
        serving_model_dir=serving_model_dir,
    )
    LocalDagRunner().run(pipeline)

if __name__ == "__main__":
    main()
